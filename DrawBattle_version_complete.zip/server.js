const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const WebSocket=require("ws");
const PORT=process.env.PORT||3000;
const rooms=new Map();
const artworks=[
 {name:"La Joconde",emoji:"🖼️"},
 {name:"La Nuit étoilée",emoji:"🌌"},
 {name:"Le Cri",emoji:"😱"},
 {name:"La Grande Vague de Kanagawa",emoji:"🌊"},
 {name:"La Persistance de la mémoire",emoji:"⏰"},
 {name:"Autoportrait",emoji:"🧑‍🎨"},
 {name:"Nature morte",emoji:"🍎"},
 {name:"Tour Eiffel",emoji:"🗼"}
];
function code(){return crypto.randomBytes(3).toString("hex").toUpperCase()}
function roomState(r){return {type:"room",phase:r.phase,code:r.code,round:r.round,host:r.host,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,score:p.score,submitted:p.submitted}))}}
function broadcast(r,msg){for(const p of r.players.values())if(p.ws.readyState===1)p.ws.send(JSON.stringify(msg))}
function sendRoom(r){broadcast(r,roomState(r))}
function startRound(r){
 r.phase="drawing";r.round++;
 const list=[...r.players.values()];
 list.forEach((p,i)=>{p.submitted=false;p.draw=null;p.art=artworks[(r.round-1+i)%artworks.length]});
 r.endsAt=Date.now()+60000;
 broadcast(r,{type:"round",round:r.round,endsAt:r.endsAt,players:list.map(p=>({id:p.id,name:p.name,art:p.art}))});
}
function finish(r){
 if(r.phase!=="drawing")return;
 r.phase="results";
 const results=[...r.players.values()].map(p=>({id:p.id,name:p.name,score:p.score,draw:p.draw||null,art:p.art}));
 // Simple fair scoring for prototype: 100 base, - time penalty, plus participation.
 results.forEach(x=>{const p=r.players.get(x.id);if(p&&p.draw)p.score+=Math.max(50,100-Math.floor((Date.now()-(r.endsAt-60000))/1200))});
 results.sort((a,b)=>b.score-a.score);
 broadcast(r,{type:"results",round:r.round,results});
 sendRoom(r);
}
const server=http.createServer((req,res)=>{
 let f=req.url.split("?")[0]; if(f==="/")f="/index.html";
 const file=path.join(__dirname,"public",f);
 if(!file.startsWith(path.join(__dirname,"public")))return res.writeHead(403).end();
 fs.readFile(file,(e,d)=>{if(e)return res.writeHead(404).end("Not found");const ext=path.extname(file);const ct={".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",".svg":"image/svg+xml"}[ext]||"application/octet-stream";res.writeHead(200,{"Content-Type":ct});res.end(d)})
});
const wss=new WebSocket.Server({server});
wss.on("connection",ws=>{
 let me=null,room=null;
 ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==="create"){let c=code();room={code:c,host:null,phase:"lobby",round:0,endsAt:0,players:new Map()};rooms.set(c,room);me={id:crypto.randomUUID(),name:(m.name||"Hôte").slice(0,18),score:0,submitted:false,ws};room.host=me.id;room.players.set(me.id,me);ws.send(JSON.stringify({type:"joined",id:me.id,code:c}));sendRoom(room)}
  else if(m.type==="join"){room=rooms.get(String(m.code||"").toUpperCase());if(!room)return ws.send(JSON.stringify({type:"error",message:"Partie introuvable"}));if(room.phase!=="lobby")return ws.send(JSON.stringify({type:"error",message:"La partie a déjà commencé"}));me={id:crypto.randomUUID(),name:(m.name||"Joueur").slice(0,18),score:0,submitted:false,ws};room.players.set(me.id,me);ws.send(JSON.stringify({type:"joined",id:me.id,code:room.code}));sendRoom(room)}
  else if(!room||!me)return;
  else if(m.type==="start"&&me.id===room.host&&room.players.size>=2){startRound(room);sendRoom(room)}
  else if(m.type==="submit"&&room.phase==="drawing"&&!me.submitted){me.submitted=true;me.draw=m.draw; if([...room.players.values()].every(p=>p.submitted))finish(room); else sendRoom(room)}
  else if(m.type==="forceResults"&&me.id===room.host)finish(room)
 });
 ws.on("close",()=>{if(room&&me){room.players.delete(me.id);if(room.players.size===0)rooms.delete(room.code);else {if(me.id===room.host)room.host=[...room.players.keys()][0];sendRoom(room)}}})
});
setInterval(()=>{for(const r of rooms.values())if(r.phase==="drawing"&&Date.now()>=r.endsAt)finish(r)},500);
server.listen(PORT,()=>console.log("DrawBattle server on "+PORT));
