const $=s=>document.querySelector(s),app=$("#app"),toastEl=$("#toast");
let ws,me,room,art=null,canvas,ctx,drawing=false,timerInt;
function toast(x){toastEl.textContent=x;toastEl.classList.add("show");setTimeout(()=>toastEl.classList.remove("show"),2200)}
function connect(){ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host);ws.onopen=()=>$("#net").textContent="🟢 En ligne";ws.onclose=()=>$("#net").textContent="🔴 Déconnecté";ws.onmessage=e=>handle(JSON.parse(e.data))}
function send(x){if(ws?.readyState===1)ws.send(JSON.stringify(x))}
function home(){app.innerHTML=`<section class="hero"><div class="logo">🎨</div><h1>DrawBattle</h1><p>Redessine des œuvres célèbres, défie tes amis et découvre qui dessine le mieux.</p><div class="card"><input id="name" placeholder="Ton prénom" maxlength="18"><div class="actions"><button class="btn" id="create">Créer une partie</button><button class="btn secondary" id="join">Rejoindre</button></div><div id="joinbox" hidden class="actions"><input id="code" placeholder="CODE" maxlength="6"><button class="btn" id="joinNow">Entrer</button></div></div></section>`;
$("#create").onclick=()=>{connect();setTimeout(()=>send({type:"create",name:$("#name").value||"Hôte"}),150)};
$("#join").onclick=()=>$("#joinbox").hidden=false;
$("#joinNow").onclick=()=>{connect();setTimeout(()=>send({type:"join",name:$("#name").value||"Joueur",code:$("#code").value}),150)}}
function handle(m){
 if(m.type==="error")return toast(m.message);
 if(m.type==="joined"){me=m.id;location.hash=m.code}
 if(m.type==="room"){room=m; if(m.phase==="lobby")lobby();else if(m.phase==="drawing"){}}
 if(m.type==="round"){art=m.players.find(p=>p.id===me)?.art;drawingScreen(m.endsAt,m.round)}
 if(m.type==="results")results(m.results,m.round)
}
function lobby(){let host=room.host===me;app.innerHTML=`<section class="card center"><h1>👥 Lobby</h1><p>Invite tes amis avec ce code :</p><div class="code">${room.code}</div><div class="qr"><img src="https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(location.href.split("#")[0]+"#"+room.code)}"></div><button class="btn secondary" id="copy">📋 Copier le lien</button><div class="players">${room.players.map(p=>`<div class="player">👤 <b>${esc(p.name)}</b><br><small>${p.id===room.host?"Hôte":"Prêt"}</small></div>`).join("")}</div>${host?`<button class="btn" id="start" ${room.players.length<2?"disabled":""}>🚀 Lancer la partie</button>`:"<p class='muted'>Attends que l’hôte lance la partie…</p>"}<p class="hint">Minimum 2 joueurs • Le QR ouvre cette partie.</p></section>`;
$("#copy").onclick=()=>navigator.clipboard?.writeText(location.href.split("#")[0]+"#"+room.code);
if(host)$("#start").onclick=()=>send({type:"start"});
}
function drawingScreen(end,round){clearInterval(timerInt);app.innerHTML=`<section class="game"><aside class="ref"><div class="art">${art.emoji}</div><h2>${esc(art.name)}</h2><p>Redessine cette œuvre. Les autres joueurs ne voient pas ton dessin avant les résultats.</p><div class="timer" id="timer">60</div></aside><div class="drawbox"><div class="tools"><button data-c="#171827">⚫</button><button data-c="#e5484d">🔴</button><button data-c="#3678e8">🔵</button><button id="erase">🧽</button><button id="clear">🗑️</button><button class="btn" id="submit">✓ Terminé</button></div><canvas id="canvas"></canvas></div></section>`;canvas=$("#canvas");ctx=canvas.getContext("2d");resize();ctx.lineCap="round";ctx.lineJoin="round";ctx.strokeStyle="#171827";ctx.lineWidth=5;
canvas.onpointerdown=e=>{drawing=true;let p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y)};canvas.onpointermove=e=>{if(!drawing)return;let p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke()};canvas.onpointerup=()=>drawing=false;canvas.onpointerleave=()=>drawing=false;
document.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{ctx.strokeStyle=b.dataset.c;ctx.lineWidth=5});$("#erase").onclick=()=>{ctx.strokeStyle="#fff";ctx.lineWidth=24};$("#clear").onclick=()=>ctx.clearRect(0,0,canvas.width,canvas.height);$("#submit").onclick=submit;
timerInt=setInterval(()=>{let n=Math.max(0,Math.ceil((end-Date.now())/1000));$("#timer").textContent=n;if(!n){clearInterval(timerInt);submit()}},250)}
function resize(){let r=canvas.getBoundingClientRect(),d=devicePixelRatio||1;canvas.width=r.width*d;canvas.height=r.height*d;ctx.scale(d,d)}
function pos(e){let r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
function submit(){if(!canvas)return;$("#submit").disabled=true;send({type:"submit",draw:canvas.toDataURL("image/png")});toast("Dessin envoyé !")}
function results(list,round){clearInterval(timerInt);let sorted=[...list].sort((a,b)=>b.score-a.score);app.innerHTML=`<section class="card"><div class="center"><h1>🏆 Résultats — manche ${round}</h1><p class="muted">Les dessins sont révélés !</p></div><div class="results">${sorted.map((p,i)=>`<article class="result"><div class="rank">${i===0?"🥇":i===1?"🥈":i===2?"🥉":"🎨"}</div><h3>${esc(p.name)}</h3>${p.draw?`<img src="${p.draw}">`:"<div class='empty'>Pas de dessin</div>"}<strong>${p.score} points</strong></article>`).join("")}</div><div class="actions"><button class="btn" id="again">Nouvelle manche</button></div></section>`;if(room.host===me)$("#again").onclick=()=>send({type:"start"});else $("#again").textContent="Attends l’hôte…"}
function esc(x){return String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}
function boot(){let h=location.hash.slice(1);home();if(h&&h.length>=4){$("#joinbox").hidden=false;$("#code").value=h.toUpperCase()}}
boot();