# DrawBattle — version multijoueur

## Fonctionnalités
- Parties réelles via WebSocket
- Minimum 2 joueurs
- Code de partie
- QR code d'invitation
- Lobby en direct
- Attribution différente d'une œuvre à chaque joueur
- Dessin tactile/souris
- Chronomètre synchronisé par le serveur
- Envoi des dessins
- Révélation des dessins
- Classement et scores
- Plusieurs manches

## Lancer sur ordinateur
1. Installer Node.js 18+.
2. Dans ce dossier : `npm install`
3. Puis : `npm start`
4. Ouvrir `http://localhost:3000`

## Pour jouer sur plusieurs téléphones
Le serveur doit être déployé sur une URL publique HTTPS (par exemple un hébergeur Node compatible WebSocket). Le QR est alors généré avec l'URL publique de la partie.

## Score
Le prototype utilise un score simple de participation/temps. Pour une version finale, on peut remplacer cela par un système de vote des joueurs ou une comparaison automatique plus sophistiquée.
